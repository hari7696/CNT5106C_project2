# CNT5106C_project2

The project incudes a simple client and server to share the files. Its supports multiple clients

By defualt the client and server run on port 5106, if no command line arguments provided

To run server and client

python server.py portnumber
python clinet.py portnumber

# interacting with client

get filename 
upload filename